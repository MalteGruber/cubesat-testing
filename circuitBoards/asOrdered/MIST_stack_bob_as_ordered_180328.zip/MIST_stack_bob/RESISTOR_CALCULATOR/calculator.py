import math
#This is a program that generates the needed resistances for the
#EPS dummy load


def printSteps(voltage,resistors):
	RESISTORS=len(resistors)
	for i in range(pow(2,RESISTORS)):


		tmp=0;

		for bit in range(RESISTORS):

			if(((i>>bit)&1)>0):
				tmp+=1/resistors[RESISTORS-1-bit]

		if(i==0):
			tmp=0.00001 #Open circuit!

		r=1/tmp
		p=voltage*voltage/r
			
		print(i,"->",round(p,2),"W",round(1000*p/voltage,4),"mA")

def getResistors(RESISTORS,max_power,voltage):
	resistors=[]
	mult=1
	for i in range(RESISTORS):
		mult=mult/2
		power=max_power*mult
		resistance=(voltage*voltage)/power;

		print("Resistor",i,"needs to dissipate",power,"W -> R =",resistance)
		resistors.append(resistance)
	return resistors




#"[V,I]"
#channels=[[3.3,2],[5,2],[5,2],[5,2],[3.3,2]]
channels=[[3.3,2],[5,2]]

RESISTORS=5

for channel in channels:
	voltage=float(channel[0])
	current=float(channel[1])

	max_power=voltage*current

	print("\n"*1)
	print("-"*80)
	print("voltage",voltage,"V current",current,"A -> max_power",max_power,"W")
	print("."*80)
	resistors=getResistors(RESISTORS,max_power,voltage)
	print("."*80)
	print("Avalible power steps ")
	printSteps(voltage,resistors)

			#print(resistors[bit])

