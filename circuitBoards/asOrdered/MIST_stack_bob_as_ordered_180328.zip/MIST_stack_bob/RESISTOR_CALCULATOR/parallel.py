




import sys



tmp=0
for i in range(1,len(sys.argv)):
	tmp+=1/(float(sys.argv[i]))

print(1/tmp,"ohm")